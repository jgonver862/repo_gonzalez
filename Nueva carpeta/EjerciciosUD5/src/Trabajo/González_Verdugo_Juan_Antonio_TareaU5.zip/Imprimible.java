package Trabajo;

public interface Imprimible {
	public void devolverInfoString();
}
